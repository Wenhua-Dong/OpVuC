function [data] = Datapre(X)

nv = length(X);
data = X;
options.ReducedDim = 100;
for v = 1:nv
    [eigvector, ~] = PCA(data{v},options);
    data{v} = data{v}*eigvector;
    data{v} = zscore(data{v});
end
end