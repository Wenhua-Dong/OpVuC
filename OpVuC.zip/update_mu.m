function [ mu ] = update_mu(Q, X, P, F, C, B, theta)

nv = length(X);
err = zeros(nv, 1);

for v=1:nv
    CB = C{v}*B;
    FCB = CB(F,:);
    XP = X{v}*P{v};
    QXP = XP(Q{v},:);
    err(v) = (sum(sum((QXP-FCB).^2)))^(1/(1-theta));
end
mu = err./sum(err);
end
