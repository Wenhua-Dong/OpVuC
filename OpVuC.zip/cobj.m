function [ objs ] = cobj(Q, X, P, F, C, B, mu, gamma)

nv = length(X);
obj = zeros(1, nv);

for v=1:nv
    CB = C{v}*B;
    FCB = CB(F,:);
    XP = X{v}*P{v};
    QXP = XP(Q{v},:);
    obj(v) = mu(v)^gamma*sum(sum((QXP-FCB).^2));
end
objs = sum(obj);
end
 