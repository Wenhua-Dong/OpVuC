function [ Q ] = update_Q(Q0, X, P, F, C, B, te, nrho,iter)

nv = length(X);
n = size(X{1},1);
k = size(C{1},1);
Q = repmat({(1:n)'},1,nv);

F2 = F(nrho+1:n);
CBte = C{te}*B;
mCBte = mean(CBte); % Center of the template
X2Pte = X{te}(nrho+1:n,:)*P{te}; 
% Distances between centroids and latent representations
D2te = EuDist2(CBte, X2Pte, 0); 
% Sort the distances between latent representations and the center
[~,Aindte] = sort(EuDist2(X2Pte, mCBte, 0)); 
for v=1:nv
    if v ~= te
        % Convert the equivalent vector into the permutation matrix
        nu = n-nrho; 
        Qm = zeros(nu);
        tmp = Q0;
        Qv = tmp{v}(nrho+1:n)-nrho;
        for i = 1:nu
            Qm(i, Qv(i)) = 1;
        end
        QmT = Qm';
        % Convert the transposition of the permutation matrix into the equivalent vector
        [~,Qs] = max(QmT,[],2);
        tmp{v}(nrho+1:n) = Qs+nrho;
        Fv = F(tmp{v});
        Fv2 = Fv(nrho+1:n);
        CBv = C{v}*B;
        mCBv = mean(CBv);
        X2Pv = X{v}(nrho+1:n,:)*P{v};
        D2v = EuDist2(CBv, X2Pv, 0);
        [~,Aindv] = sort(EuDist2(X2Pv, mCBv, 0));
        Q2 = zeros(n-nrho,1);
        % Global alignment
        if iter<51
            Q2(Aindte) = Aindv;
        else
            % Local alignment
            for i = 1:k
                indti = find(F2==i); % Indices of the i-th cluster
                indvi = find(Fv2==i);
                [~,indts] = sort(D2te(i,indti),2); 
                [~,indvs] = sort(D2v(i,indvi),2); 
                % Generate the permutation according to the nearest distance
                Q2(indti(indts)) = indvi(indvs);
            end
        end
        Q{v}(nrho+1:end) = Q2'+nrho; 
    end
end
