function [P, Q0, F, C, B, obj] = OpVuC( X, k, nrho, te, theta, redim)
% Objective function: min sum_{v=1}^{nv} mu_{v}^theta*||QvXvPv-FCvB||_F^2
% s.t. Pv^{T}Pv=I, BB^{T}=I, sum_{v=1}^{nv} mu_{v}=1.
% Remark: When verifying the results in the paper, please remove the seed 
% of the random number stream in OpVuC, lines 13-14.

nv = length(X);
n = size(X{1}, 1);
c = k;
maxIter = 100;

% Initialization
s = RandStream('mt19937ar','Seed',0);
RandStream.setGlobalStream(s);
P = cell(1,nv);
C = cell(1,nv);
B = rand(c,redim);
Q0 = repmat({(1:n)'},1,nv);
for v=1:nv
    P{v} = rand(size(X{v},2),redim);
    C{v} = rand(k,c);
    if nrho<n
        if v ~= te
            Q0{v}(nrho+1:n) = nrho+randperm(n-nrho)';
        end
    end
end
F = randi([1,k],n,1);
mu = ones(nv,1)./nv;

obj = zeros(1,maxIter);
for j = 1:maxIter
    % Calculate the objective value
    [ obj(j) ] = cobj(Q0, X, P, F, C, B, mu, theta);
    % Update P
    [ P ] = update_P(Q0, X, F, C, B);
    % Update B
    [ B ] = update_B(Q0, X, P, F, C, mu, theta);
    % Update C
    [ C ] = update_C(Q0, X, P, F, B, k);
    % Update F
    [ F ] = update_F( Q0, X, P, C, B, k, mu, theta,te);
    % Update Q
    if nrho<n
        [ Q ] = update_Q(Q0, X, P, F, C, B, te, nrho, j);
        Q0 = Q;
    end
    % Update mu
    [ mu ] = update_mu(Q0, X, P, F, C, B, theta);

    if j>80 && abs(obj(j)-obj(j-1))/obj(j) < 1e-6
        break;
    end

end
end

