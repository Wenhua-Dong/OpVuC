function [ F ] = update_F( Q, X, P, C, B, k, mu, theta, te)

nv = length(X);
n = size(X{1}, 1);
ind = zeros(n,nv);
SD = zeros(n, k);
F = zeros(n,1);

for v=1:nv     
    CB = C{v}*B;
    XP = X{v}*P{v};
    QXP = XP(Q{v},:);
    Dv = EuDist2(QXP, CB, 0); 
    SD =  SD+mu(v)^theta* Dv;
    [~,ind(:,v)] = min(Dv,[],2);
end
SD = SD./repmat(sqrt(sum(SD.^2,1)),n,1);
for i = 1:n
    if ind(i,:)==ind(i,te)
        F(i) = ind(i,te);
    else
       [~, F(i)] = min(SD(i,:),[],2);
    end
end