function [ B ] = update_B(Q, X, P, F, C, mu, theta)

nv = length(X);
[k, c] = size(C{1});
tmp = 0;

for v=1:nv
    XP = X{v}*P{v};
    QXP = XP(Q{v},:);
    FtQXP = zeros(k, size(QXP,2));
    for j=1:k
        FtQXP(j,:) = sum(QXP(find(F==j),:), 1)+eps;
    end
    tmp = tmp + mu(v)^theta*C{v}'*FtQXP;
end
[U,~,V] = svds(tmp, c);
B = U*V';
end