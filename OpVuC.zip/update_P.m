function [ P ] = update_P( Q, X, F, C, B )

nv = length(X);
P = cell(1, nv);

for v=1:nv
    CB = C{v}*B;
    FCB = CB(F,:);
    QX = X{v}(Q{v},:);
    tmp = QX'*FCB;
    [U,~,V] = svd(tmp, 'econ');
    P{v} = U*V';
end
end