clear; close all; clc;
% Objective function: min sum_{v=1}^{nv} mu_{v}^theta*||QvXvPv-FCvB||_F^2
% s.t. Pv^{T}Pv=I, BB^{T}=I, sum_{v=1}^{nv} mu_{v}=1.
% Remark: (1) For the template selection, please refer to the manuscript.
% (2) When verifying the results in the paper, please remove the seed of 
% the random number stream in OpVuC, lines 13-14.

addpath([pwd, '/dataset']);
addpath([pwd, '/tools']);
% load dataset
load Pascal.mat

nv = length(X);
n = size(X{1},1);
k = length(unique(gt));
numRepeat = 1; % 10
redim = round(1.5*k); 
% Alignment ratio
rho = 0;
nrho = round(rho*n);
% The index of the template 
te = 2;  
% Parameter setting
theta = 1.2;

% Data preprocessing
data = Datapre(X);
% Shuffle the data
if nrho<n
    [sdata, gnd] = Shuffle_data(data,nrho,gt,te);
else
    sdata = data;
    gnd = gt;
end

%% Run OpVuC
results = zeros(numRepeat,3);
for iter = 1:numRepeat
    tic;
    [Q, P, F, C, B, obj] = OpVuC(sdata, k, nrho, te, theta, redim);
    ts = toc;    
    metric = clustering(F, gnd);
    fprintf('\n Metric: ACC: %.4f, NMI: %.4f, ARI: %.4f', metric(1), metric(2), metric(3));
%     results(iter,:) = metric;
    clear Q P F C B obj metric
end
% mmetric = mean(results);
% fprintf('\n Average: ACC: %.4f, NMI: %.4f, ARI: %.4f', mmetric(1), mmetric(2), mmetric(3));

