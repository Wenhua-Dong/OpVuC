function [sdata,gnd] = Shuffle_data(X,nrho,gt,te)

nv = length(X);
n = size(X{1},1);
sdata = cell(1,nv);
ind = cell(1,nv);
rind = (1:n)';
aind = randperm(n,nrho)';
rind(aind) = [];
for v=1:nv
    sind = randperm(n-nrho);
    ind{v} = [aind; rind(sind)];
    sdata{v} = X{v}(ind{v},:);
end
gnd = gt(ind{te});
clear ind rind aind sind
end