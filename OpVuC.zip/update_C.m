function [ C ] = update_C(Q, X, P, F, B, k)

nv = length(X);
n = size(X{1},1);

FtF_vec = zeros(k,1);
for i=1:n
    FtF_vec(F(i)) = FtF_vec(F(i)) + 1;
end
FtF_invec = 1./(FtF_vec+eps);

for v=1:nv
    XP = X{v}*P{v};
    QXP = XP(Q{v},:);
    FtQXP = zeros(k, size(QXP,2));
    for j=1:k
        FtQXP(j,:) = sum(QXP(find(F==j),:), 1);
    end
    tmp = FtQXP.*repmat(FtF_invec, 1, size(FtQXP,2));
    C{v} = tmp*B';
end
end